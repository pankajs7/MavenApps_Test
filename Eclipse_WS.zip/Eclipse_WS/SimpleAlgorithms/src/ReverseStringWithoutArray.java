import java.util.Scanner;


public class ReverseStringWithoutArray {
public static void main(String[] args) {
	
Scanner scanner=new Scanner(System.in);
System.out.println("Enter a Stringh : ");
String orderedString=scanner.nextLine();
String reverseString="";

int strLength=orderedString.length();
for(int count=strLength-1;count>= 0;count--){
	reverseString=reverseString+orderedString.charAt(count);
}
System.out.println("Reversed String : "+reverseString);
}
}
