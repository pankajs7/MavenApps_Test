import java.util.Scanner;


public class ReverseStringUsingArray {
public static void main(String[] args) {
	int i=10;
i++;
	System.out.println(i);
	
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter a string : ");
	String orderedString=scanner.nextLine();
	String reverseString="";
	String[] strArray=orderedString.split("");
	int length=strArray.length;
	for(int count=length-1;count>=0;--count){
	reverseString=reverseString+strArray[count];
	}
System.out.println(reverseString);	
}
}
