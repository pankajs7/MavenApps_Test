import java.util.Scanner;


public class ReverseStringUsingWhile {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter a String : ");
	String strOrdered=scanner.nextLine();
	String strReverse="";
	int length=strOrdered.length();
	while(length>0){
		strReverse=strReverse+strOrdered.charAt(length-1);
		--length;
	}
	System.out.println(strReverse);
}
}
