interface Demo{
	void m1();
}
class DemoImpl implements Demo
{
	public void m1(){
		System.out.println();
	}
}
public class CheckInterfaceMethod {
	
public static void main(String[] args) {
	
}
}
