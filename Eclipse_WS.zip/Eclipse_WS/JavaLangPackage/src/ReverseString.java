import java.util.Scanner;


public class ReverseString {
public static void main(String[] args) {
	 Scanner scanner = new Scanner(System.in);
     System.out.println("Enter a String");
     String str = scanner.nextLine();
     char[] inputArray=str.toCharArray();
     
     int length=inputArray.length;
     char[] resultArray=new char[length];
     for(int count=length-1;count>=0;count--){
    	 resultArray[count]=inputArray[count];
    	 System.out.print(resultArray[count]);
     }
}
}
