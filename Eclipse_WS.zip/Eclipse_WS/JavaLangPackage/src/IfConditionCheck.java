
public class IfConditionCheck {
public static void main(String[] args) {
	m1();
}
static void m1(){
	System.out.println("Hello");
	if(true){
		System.out.println("Pankaj");
		//break;
	}
	System.out.println("HIII");
}
}
