
public class DemoSample {
public static void main(String[] args) {
	int String=10;
	System.out.println(String);
}
}
