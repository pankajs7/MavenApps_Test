interface FunctionalInterf{
int sum(int x,int y);
}
class FunctionalInterfImpl{
	public int summation(int a,int b){
		int c=a+b;
		System.out.println("Instance Method Reference::  Sum :"+c);
		return c;
	}
	public long summation(long a,long b){
		long c=a+b;
		System.out.println("Instance Method Reference::  Sum :"+c);
		return c;
	}
	/*public int Addition(int a,int b,int d){
		int c=a+b;
		System.out.println("Instance Method Reference::  Sum :"+c);
		return c;
	}*/
}
public class MethodReferenceExample {
public static void main(String[] args) {
	FunctionalInterfImpl impl=new FunctionalInterfImpl();
	FunctionalInterf interf=impl::summation;
	interf.sum(10, 20);
}
}
