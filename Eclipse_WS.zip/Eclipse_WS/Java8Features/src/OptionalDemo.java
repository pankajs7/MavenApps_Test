import java.util.Optional;


public class OptionalDemo {
public static void main(String[] args) {
	
	String str=null;
	String str2=new String();
	
	Optional nullCheck=Optional.ofNullable(str);
	Optional optionalValue=Optional.of(str2);
	Optional<String> gender = Optional.of("MALE");
	Optional emptyString=Optional.empty();
	
	/*System.out.println(optionalValue.isPresent());
	if(nullCheck.isPresent())
		System.out.println("Present");
	else
		System.out.println("Not Present- null");
	
	System.out.println(gender.orElse("NA"));
	System.out.println(emptyString.orElseGet(()->"NA"));
	nullCheck.ifPresent(v-> System.out.println("I am not printing"));*/
	new OptionalDemo().m1();
}
public void m1(){
	String testStr = "Studytonight";
	String orElseGetStr = Optional.ofNullable(testStr).orElseGet(()->setDefault());
	System.out.println("Default String for orElseGet is: " + orElseGetStr);
	String orElseStr = Optional.ofNullable(testStr).orElse(setDefault());
	System.out.println("Default String for orElse is: " + orElseStr);
}
public  String setDefault() {
    System.out.println("Setting default value...");
    return "Default";
}
}
