import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;


public class MapValuesSorting {
public static void main(String[] args) {
	Map<Integer,Integer> map=new HashMap();
	map.put(10, 2);
	map.put(2, 20);
	map.put(20, 5);
	map.put(15, 35);
	
	map.entrySet().stream().sorted((entry1,entry2)->entry2.getValue().compareTo(entry1.getValue()))
	.forEach(entry->System.out.println(entry.getKey()+" "+entry.getValue()));
	
	map.entrySet().stream().sorted((entry1,entry2)->entry2.getValue().compareTo(entry1.getValue()))
	.forEach(System.out::println);
	
	/*Map<Integer,Integer> sortedMap=map.entrySet().stream()
			.sorted((e1,e2)->e2.getValue().compareTo(e1.getValue()))
			.collect(Collectors.toMap(entry->((Map.Entry<Integer,Integer>)entry).getKey(),((Map.Entry<Integer,Integer>)entry).getValue()));
Collectors.to*/
}
}
