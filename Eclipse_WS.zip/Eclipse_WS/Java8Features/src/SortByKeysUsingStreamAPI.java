import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;


public class SortByKeysUsingStreamAPI {
public static void main(String[] args) {
	Map<Integer,Integer> map=new HashMap();
	map.put(10, 2);
	map.put(2, 20);
	map.put(20, 5);
	map.put(15, 35);
	Map<Integer,Integer> sortedMap=new LinkedHashMap<Integer, Integer>();
	Map<Integer,Integer> reverseSortedMap=new LinkedHashMap<Integer, Integer>();
	map.entrySet().stream()
	.sorted(Map.Entry.comparingByKey(Comparator.reverseOrder()))
	.forEachOrdered(e->reverseSortedMap.put(e.getKey(), e.getValue()));
	
	map.entrySet().stream()
	.sorted(Map.Entry.comparingByKey())
	.forEachOrdered(e-> sortedMap.put(e.getKey(), e.getValue()));
	System.out.println(sortedMap);
	System.out.println(reverseSortedMap);
}
}
