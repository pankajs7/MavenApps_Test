import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


public class RemoveDuplicate {
public static void main(String[] args) {
	List list=Arrays.asList("Pankaj","Kumar","Pankaj","Singh","Singh","Pankaj");
	List<String> updatedList=(List<String>) list.stream().distinct().collect(Collectors.toList());
	System.out.println(updatedList);
	
}
}
