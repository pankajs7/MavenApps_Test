interface DefaultMethodInterface{
	 static void say(){    
        System.out.println("Hello, this is say() method");    
    }  
	 default void sayHi(){    
	        System.out.println("Hi, this is sayHi() method");    
	    }  
}
interface DefaultMethodSecondInterface{
	default void sayHi(){
		System.out.println("Hi, This is sayHi() of DefaultSecondMethod");
	}
}
class DefualtMethodImpl implements DefaultMethodInterface,DefaultMethodSecondInterface{
	public void sayHi(){
	DefaultMethodInterface.super.sayHi();
	DefaultMethodSecondInterface.super.sayHi();
	System.out.println("This is DefaultMethodImpl sayHi() method");
	}
}
public class DefaultMethodExample{
public static void main(String[] args) {
	DefaultMethodInterface.say();
	DefualtMethodImpl impl=new DefualtMethodImpl();
	impl.sayHi();
	
}

}
