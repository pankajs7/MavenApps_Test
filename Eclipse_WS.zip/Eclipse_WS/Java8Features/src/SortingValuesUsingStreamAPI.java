import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;


public class SortingValuesUsingStreamAPI {
public static void main(String[] args) {
	Map<Integer,Integer> map=new HashMap();
	map.put(10, 2);
	map.put(2, 20);
	map.put(20, 5);
	map.put(15, 35);
	Map<Integer,Integer> sortedMap=new LinkedHashMap<Integer, Integer>();
	Map<Integer,Integer> reverseSortedMap=new LinkedHashMap<Integer, Integer>();
	
	map.entrySet().stream()
	.sorted(Map.Entry.comparingByValue())
	.forEachOrdered(entry-> sortedMap.put(entry.getKey(), entry.getValue()));
	
	map.entrySet().stream().sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
	.forEachOrdered(entry-> reverseSortedMap.put(entry.getKey(), entry.getValue()));
	
	System.out.println(sortedMap);
	System.out.println(reverseSortedMap);
	
}
}
