import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.stream.Collectors;


public class CheckStringInitialLetter {
public static void main(String[] args) {
	List<Empl0yee> list=new ArrayList<Empl0yee>();
	list.add(new Empl0yee(1000,"Pankaj"));
	list.add(new Empl0yee(1001,"Chandan"));
	list.add(new Empl0yee(1002,"Indra"));
	list.add(new Empl0yee(1003,"Priyanka"));
	list.add(new Empl0yee(1004,"Pankaj"));
	//list.stream().filter(emp->emp.getEname().startsWith("P"))
	//.forEach(emp->System.out.println(emp.getEmpId()+" "+emp.getEname()));
	List<Empl0yee> updateList=list.stream()
			        .filter(emp->emp.getEname().endsWith("a")).collect(Collectors.toList());
	
	updateList.stream()
	.forEach(emp-> System.out.println(emp.getEmpId()+" "+emp.getEname()));
	
			
}
}
