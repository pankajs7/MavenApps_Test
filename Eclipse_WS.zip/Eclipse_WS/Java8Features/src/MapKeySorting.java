import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;


public class MapKeySorting {
public static void main(String[] args) {
	Map<Integer,Integer> map=new HashMap();
	map.put(10, 2);
	map.put(2, 20);
	map.put(20, 5);
	map.put(15, 35);
	//System.out.println(map);
	
	//map.entrySet().stream().forEach(entry-> System.out.print(entry.getKey()+" "+entry.getValue()+" "));
	
	/*map.entrySet().stream().sorted((entry1,entry2)->entry1.getKey().compareTo(entry2.getKey()))
	.forEach(entry-> System.out.println(entry.getKey()+" "+entry.getValue()+" "));*/
	map.entrySet().stream()
	.sorted((I1,I2)-> -I1.getKey().compareTo(I2.getKey()))
	.forEach(System.out::println);
	
	
}
}
