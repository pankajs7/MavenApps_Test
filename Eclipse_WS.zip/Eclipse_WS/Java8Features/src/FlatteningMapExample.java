import java.util.Arrays;
import java.util.List;


public class FlatteningMapExample {
public static void main(String[] args) {
	List<Empl0yee> list1=Arrays.asList(new Empl0yee(10,"Pankaj"),
			new Empl0yee(2,"Chandan"),
			new Empl0yee(5,"Singh"),
			new Empl0yee(20,"Kumar"),
			new Empl0yee(1001,"Priyanka"));

List<Empl0yee> list2=Arrays.asList(new Empl0yee(10,"Pankaj"),
		new Empl0yee(2,"Chandan"),
		new Empl0yee(5,"Singh"),
		new Empl0yee(20,"Kumar"),
		new Empl0yee(1001,"Priyanka"));

List<Empl0yee> list3=Arrays.asList(new Empl0yee(10,"Pankaj"),
		new Empl0yee(2,"Chandan"),
		new Empl0yee(5,"Singh"),
		new Empl0yee(20,"Kumar"),
		new Empl0yee(1001,"Priyanka"));
List<List<Empl0yee>> listOfList=Arrays.asList(list1,list2,list3);

listOfList.stream().flatMap(empList->empList.stream() ).forEach(emp-> System.out.println(emp.getEmpId()+" "+emp.getEname()));
}
}
