import java.util.Arrays;
import java.util.Collections;
import java.util.List;

class Empl0yee {
	int empId;
	String ename;
	public Empl0yee(int empId,String name) {
		this.empId=empId;
		this.ename=name;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
public String toString(){
	return empId+" "+ename;
}
}

public class CollectionsSort {
public static void main(String[] args) {
	
	List list=Arrays.asList(new Empl0yee(10,"Pankaj")
	          ,new Empl0yee(20,"Chandan")
	          ,new Empl0yee(30,"Priyanka")
	,new Empl0yee(2,"Singh"));
	
	System.out.println(list);
}
}
