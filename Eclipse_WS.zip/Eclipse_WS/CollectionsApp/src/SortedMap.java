import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public class SortedMap {
public static void main(String[] args) {
	Map<Integer,Integer> map=new HashMap();
	map.put(10, 2);
	map.put(2, 20);
	map.put(20, 5);
	map.put(15, 35);
	System.out.println(map);
	List<Map.Entry<Integer, Integer>> list=new ArrayList<Map.Entry<Integer,Integer>>(map.entrySet()); 
	
	/*Collections.sort(list,new Comparator<Map.Entry<Integer,Integer>>(){
		public int compare(Map.Entry<Integer, Integer> entry1,Map.Entry<Integer, Integer> entry2){
			Integer i1=entry1.getValue();
			Integer i2=entry2.getValue();
			return i1.compareTo(i2);
		}
	});*/
	Collections.sort(list, new Comparator(){
		public int compare(Object obj1,Object obj2){
			int i1=((Map.Entry<Integer, Integer>)obj1).getValue();
			int i2=((Map.Entry<Integer, Integer>)obj2).getValue();
			return Integer.valueOf(i2).compareTo(Integer.valueOf(i1));
		}
	});
	
	Map sortedMap=new LinkedHashMap();
for(Map.Entry entry : list){
		sortedMap.put(entry.getKey(), entry.getValue());
	}

System.out.println(sortedMap);
/*List<String> li=Arrays.asList("Pankaj","Chandan");
for(String str : li){
	System.out.println(str);
}*/
}
}
